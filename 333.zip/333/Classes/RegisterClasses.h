#pragma once
/*
 *  RegisterClasses.h
 *  iPhone-target2
 *
 *  Created by Renaldas on 8/26/08.
 *  Copyright 2008 __MyCompanyName__. All rights reserved.
 *
 */

void RegisterAllClasses();


